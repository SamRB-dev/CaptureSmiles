# MuseBot > 2024-09-04 4:35am
https://universe.roboflow.com/selfdriving-captb/musebot

Provided by a Roboflow user
License: CC BY 4.0

